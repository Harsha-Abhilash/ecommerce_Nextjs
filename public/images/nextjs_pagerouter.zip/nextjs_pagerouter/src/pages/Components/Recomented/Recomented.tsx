import ProductCard from '../ProductCard/ProductCard'
import { Product_services } from "../../Services/ProductServices";

interface Product {
  documentId: string; 
  title:string;
  price:number;
  image:string
  category:string 
}

interface ProductsProps {
  sliced: Product[];
}

export async function getServerSideProps() {
  const product = await Product_services.Get_product();
  const sliced = product.slice(2, 7);  
  return {
    props: { products:sliced }, 
  };
}

export default function Recomented( {products}:{products:ProductsProps[]}) {
    console.log("sliced",products)
  return (
  
    <div className="row">
      {products.map((p: ProductsProps) => {
        return <ProductCard product={p} />;
      })}
    </div>
  );
}
